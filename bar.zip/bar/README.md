# Bar Odoo
Modulo de Odoo de un Bar que ofrece tapas
