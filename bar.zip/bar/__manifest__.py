{
    'name' : 'Bar',
    'summary' : 'Modulo Bar',
    'author' : 'Jose Juan Vico',
    'version' : '0.2',
    'website' : 'google.com',
    'depends' : ['base'],
    'data' : ['views/empleados.xml', 'views/bebida.xml', 'views/tapa.xml', 'views/comida.xml']
}
