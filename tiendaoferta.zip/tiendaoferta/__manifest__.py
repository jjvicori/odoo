{
    'name' : 'Tienda con Ofertas',
    'summary' : 'Modulo de tienda con ofertas',
    'author' : 'Jose Juan',
    'version' : '1.1',
    'website' : 'google.com',
    'depends' : ['base'],
    'data' : ['views/categoria.xml', 'views/productos.xml', 'views/ofertas.xml', 'views/clientes.xml']
}
