from odoo import models, fields

class Productos(models.Model):
    _name = 'tienda.productos'
    codigo = fields.Integer('Codigo', required=True)
    nombre = fields.Char('Nombre', required=True)
    marca = fields.Char('Marca', required=True)
    precio = fields.Float('Precio', required=True)
