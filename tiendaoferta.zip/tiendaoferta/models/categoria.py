from odoo import models, fields

class Categoria(models.Model):
    _name = 'tienda.categoria'
    codigo = fields.Integer('Codigo', required=True)
    nombre = fields.Char('Nombre', required=True)
    precio = fields.Float('Precio', required=True)
    temporada = fields.Char('Temporada', required=False)
