from odoo import models, fields, api

class Ofertas(models.Model):
    _name = 'tienda.ofertas'
    codigo = fields.Integer('Codigo', required=True)
    nombre = fields.Char('Nombre', required=True)
    descuento = fields.Float('Descuento', required=True)
    cantidad = fields.Float('Cantidad', required=True)
    perecedero = fields.Boolean('Activa', required=True)
    clientes = fields.Many2one('tienda.clientes', 'Clientes')

    _sql_constraints=[ ('codigo_unique','unique(codigo)','El codigo del articulo no puede repetirse.')]

    @api.one
    def aniadir(self):
        self.cantidad = self.cantidad + 1
